
what: Elbrus SKYBOX . Named after the real mountain, though it doesn't really looks like it.

game: it`s made and tweaked for q3, but should work in any game/prog that supports quake3 standard skyboxes (scroll down for more info). Convert yourself, or contact me and I`ll do another format for you. 


looks:	brown-dirty mountains, dark sky - grim skybox for a gloomy quake map
size:		512x512 (JPGs)

Autor: Speedy
	 www.planetquake.com/speedy
	 speeds@softhome.net
	 ICQ 68154481	

build time:  ~2 hrs
editors used: Bryce4, PS

thanx to: sock (www.planetquake.com/simland) for q3 skybox shader example, and tutorial  

Use it in your map or wherever (NON-commercial use only). Just give me a credit, and  drop me a mail, I`d like to look at your work.


How to use in quake:
--------------------
For q1 requires new engine (like TQ, MHQ or Nehahra) AND you`ll need to convert this box. TQ doesnt support jpg afaik, HM quake needs 256x256 size jpg/tga/pcx(256 colors), so shrink it. Follow the instructions that come with engine. In case you want this box, but cant convert it - mail me -  I`ll do diffrent format for your needs.

For q2 you`d need to convert to tga and resize to 256 square I think. Put into baseq2/env folder (you need to have 256 color pcx versions for software)

For q3 - just unzip all into baseq3, keeping the folder structure, everything is set for you,
THEN
Goto the SCRIPTS sub-directory under the BASEQ3  and in the file SHADERLIST.TXT   
add the line at the bottom (the name of the .sahder) : elbrus

in q3 map editor use the texture called elbrus_skybox, not elbrus_view


Any problems - contact me.

date: 4 jan 2002


________________________
Copyright:
NON-commercial use only (either on its own or as a part of a product).
In other case you have to obtain my written permision.

You may modify for your own needs just give me a credit and let me know. 

You MAY distribute this file through any electronic network (internet,
local BBS etc.), provided you include this file and leave the 
zip archive intact.

