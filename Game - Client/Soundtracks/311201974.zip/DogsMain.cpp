#include <iostream>
#include <vector>
#include <algorithm>
using namespace std;
	struct Dog // node 
	{
		Dog(int size) : Size(size) {}
		operator int() { return this->Size; }
		int Size;
	};
bool sortfunction(const vector<Dog>::iterator lhs, const vector<Dog>::iterator rhs);


void main()
{

	struct DogDifference {
		DogDifference(vector<Dog>::iterator Dog1, vector<Dog>::iterator Dog2, int Difference)
		{
			this->Dog1 = Dog1;
			this->Dog2 = Dog2;
			this->Difference = Difference;
		}
		vector<Dog>::iterator Dog1, Dog2;
		int Difference;
	};
	vector<Dog>::iterator
		DogIterator;
	vector<Dog> Dogs;
	Dogs.push_back(1);
	Dogs.push_back(1);

	Dogs.push_back(3);
	Dogs.push_back(7);
	Dogs.push_back(9);
	Dogs.push_back(14); // 0 2 4 2 5
	typedef vector<vector<Dog>::iterator> Walker;

	vector<Walker> Walkers;

	vector<DogDifference> SizeDifferences;
	int numWalkers;
	printf("Input the number of walkers:");
	std::cin >> numWalkers;
	Walkers.resize(numWalkers);
	for (int i = 0; i < Dogs.size() - 1; i++)
	{
		SizeDifferences.push_back(DogDifference(
			Dogs.begin() + i,
			Dogs.begin() + i + 1,
			Dogs[i + 1] - Dogs[i]
		));
	}
	std::sort(SizeDifferences.begin(), SizeDifferences.end(),
		[](const DogDifference lhs, const DogDifference rhs)->bool { return lhs.Difference > rhs.Difference; }); // Greater
																												 //// 0 2 2 4 5
	auto SearchFirstAcceptingWalker = [](decltype(DogIterator)& doggo, decltype(Walkers)& Walkers)mutable->void {
		for (auto wit = Walkers.begin(); wit != Walkers.end(); wit++)
		{
			auto& w = *wit;
			if (w.size() == 0)
			{
				w.push_back(doggo);
				return;
			}
		}

		Walker* BestGroup = nullptr;
		int BestMatch = 1000;
		for (auto wit = Walkers.begin(); wit != Walkers.end(); wit++)
		{
			auto& w = *wit;
			
			for (auto Dogit = w.begin(); Dogit != w.end(); Dogit++)
			{
				auto& DogIterator = *Dogit;
				if (DogIterator + 1 == doggo)
				{
					if (BestGroup == nullptr) {
						BestGroup = &w;
					}
					if (abs((DogIterator + 1)->Size - doggo->Size) < BestMatch)
					{
						BestGroup = &w;
						BestMatch = abs((DogIterator)->Size - doggo->Size);
					}
				}
					
				if(doggo + 1 == DogIterator)
				{
					if (BestGroup == nullptr) {
						BestGroup = &w;
					}
					if (abs((DogIterator)->Size - (doggo + 1)->Size) < BestMatch)
					{
						BestGroup = &w;
						BestMatch = abs((DogIterator)->Size - (doggo)->Size);
					}
				}
			}
		}
		BestGroup->push_back(doggo);
	};
	for (auto i = SizeDifferences.begin(); i != SizeDifferences.end(); i++)
	{
		auto doggo = i->Dog2;
		SearchFirstAcceptingWalker(i->Dog2, Walkers);
		//auto x = Walkers.at(0).at(0);
	}
	auto CalculateWalkerTotalDiff = [](vector<Dog*> walker)->int
	{
		sort(walker.begin(), walker.end(), [](const Dog* lhs, const Dog* rhs)->bool {
			return lhs->Size < rhs->Size;
		});
		int sum = 0;
		for (int i = 1; i < walker.size(); i++)
		{
			sum += abs(walker[i]->Size - walker[i - 1]->Size);
		}
		return sum;
	};
	int sum = 0;
	// this is not part of the algorithm. it's part of the fact that vs2010 can't handle half of c++ and those are the 'rules' of this project.
	vector<vector<Dog*>> vWalkers; 
	for each (auto w in Walkers)
	{
		vector<Dog*> vWalker;
		for each (auto d in w)
		{
			vWalker.push_back(&(*d));
		}
		vWalkers.push_back(vWalker);
	}
	// continue the calculation.
	for each(auto w in vWalkers)
	{
		sum += CalculateWalkerTotalDiff(w);
	}
	cout << sum;
	std::cin.get();
	std::cin.get();
}
