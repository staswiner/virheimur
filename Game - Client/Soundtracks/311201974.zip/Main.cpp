#include <iostream>
#include <vector>

using namespace std;
void main()
{   //  1   2   3  4  5 6 7 7 6  5  4  3  2  1
	// -12 -10 -6 -5 -3 3 4 6 10 12 15 20 21 22 
	int xarray1[] = { -5  };
	int xarray2[] = { -12, -10, -6, -3, 4, 10 };
	vector<int> array1(xarray1,xarray1 + sizeof(xarray1)/sizeof(xarray1[0]));
	vector<int> array2(xarray2,xarray2 + sizeof(xarray2)/sizeof(xarray2[0]));
	vector<int> *storage1, *storage2, *storagex;
	storage1 = &array1;
	storage2 = &array2;

	int i,j;
	int m,n;
	auto FindHalf = [](vector<int> array) -> int {
		return array[array.size() / 2];
	};
#define SWAP(x,y,c) \
	c=x; \
	x=y; \
	y=c;

	m = array1.size();
	n = array2.size();
	while (1)
	{
		if (array2.size() == 1)
		{
			cout << array2[0];
			break;
		}
		if (array1.size() == 1)
		{
			cout << array1[0];
			break;
		}
		if (array2.size() == 0)
		{
			cout << array1[(array1.size() / 2) - 1];
			break;
		}
		if (array1.size() == 0)
		{
			cout << array2[(array2.size() / 2) - 1];
			break;
		}
		//====+++++ //----====
		if (FindHalf(*storage1) > FindHalf(*storage2))
		{
			SWAP(storage1, storage2, storagex)
		}
		//----==== //====+++++
		else
		{
			/*
			to reduce computation time of copying arrays, 
			it is better using index pointers such as "int array1start, array1end, array1middle"
			but it would make it a much less pretty code. it changes the complexity by multiplying it by 'n'.
			i left it like that for simplicity, but i'm aware of the optimization that is possible to apply in here.
			*/
			i = (*storage1).size() / 2;
			(*storage1) = vector<int>((*storage1).begin() + (i), (*storage1).end());
			(*storage2) = vector<int>((*storage2).begin(), (*storage2).end() - (i));
		}
	}
	cin.get();
}